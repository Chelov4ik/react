import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const MovieDetails = ({ movies }) => {
  const { id } = useParams(); //id из ссылки 
  const movie = movies[parseInt(id)]; 

  const navigate = useNavigate();

  const navigateTo = (path) => {
    navigate(path);
  };

  if (!movie) {
    return <div>Фильм не найден</div>;
  }

  return (
    <div className="center-flex" style={{display:'flex', flexDirection:'column',alignItems: 'center',textAlign:'center'}}>
      <div className="movie-details" style={{paddingBottom:15}}>
        <img src='/SpongeBob.jpg' style={{width: '100%'}}/>
        <h1 style={{fontSize: 50, paddingTop: 15}}>{movie.title}</h1>
        <p style={{fontSize: 30, paddingTop: 15}}>Дата выхода: {movie.releaseDate}</p>
        <p style={{fontSize: 30, paddingTop: 15}}>описание: {movie.descr}</p>
      </div>
      <button onClick={() => navigateTo("/")} style={{backgroundColor: 'black', color: 'white',width: 300,height: 90, borderRadius: '10px', fontSize: 30}}>Back</button>
    </div>
  );
}

export default MovieDetails;
