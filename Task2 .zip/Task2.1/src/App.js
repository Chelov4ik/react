import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Films from "./Films"; 
import FilmDetails from "./FilmDetails"; 

function App() {
  const movies = [
    { title: "Губка в поисках приключений", releaseDate: "06-25-2024",image: "/SpongeBob.jpg", descr: "Special film for real men"},
    { title: "Губка в поисках депрессии", releaseDate: "06-26-2024",image: "/SpongeBob.jpg", descr: "Special film for real men"},
    { title: "Губка Боб: Идеальный бургер", releaseDate: "06-27-2024",image: "/SpongeBob.jpg", descr: "Special film for real men"},
    { title: "Белка в аквариуме", releaseDate: "06-28-2024",image: "/SpongeBob.jpg", descr: "Special film for real men"},
    { title: "подводная поп стар", releaseDate: "06-29-2024",image: "/SpongeBob.jpg", descr: "Special film for real men"},
    { title: "Боб за Патриковый район", releaseDate: "06-30-2024",image: "/SpongeBob.jpg", descr: "Special film for real men"},
    { title: "Боб на грани с зеленным", releaseDate: "07-1-2024",image: "/SpongeBob.jpg", descr: "Special film for real men"},
    { title: "Боб и рост монсра гэри", releaseDate: "07-3-2024",image: "/SpongeBob.jpg", descr: "Special film for real men"},
    { title: "Боб и вечный подводный огонь", releaseDate: "07-6-2024",image: "/SpongeBob.jpg", descr: "Special film for real men"},
    { title: "Губка в поисках приключений 2", releaseDate: "07-8-2024" ,image: "/SpongeBob.jpg" , descr: "Special film for real men"},
    { title: "Губка в поисках депрессии 2", releaseDate: "07-11-2024" ,image: "/SpongeBob.jpg" , descr: "Special film for real men"},
    { title: "Губка Боб: Идеальный бургер 2", releaseDate: "07-14-2024" ,image: "/SpongeBob.jpg" , descr: "Special film for real men"},
    { title: "Боб и рост монсра гэри 2", releaseDate: "07-19-2024" ,image: "/SpongeBob.jpg" , descr: "Special film for real men"},
    { title: "Боб и рост монсра гэри 3", releaseDate: "07-22-2024" ,image: "/SpongeBob.jpg" , descr: "Special film for real men"},
    { title: "Боб и новое поколение", releaseDate: "07-25-2024" ,image: "/SpongeBob.jpg" , descr: "Special film for real men"},
    { title: "Боб и война поколений", releaseDate: "07-29-2024" ,image: "/SpongeBob.jpg" , descr: "Special film for real men"},
    { title: "Боб и война поколений финал", releaseDate: "02-30-2025" ,image: "/SpongeBob.jpg" , descr: "Special film for real men"},
  ];

  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Films movies={movies} />} />
        <Route path="/films" element={<Films movies={movies} />} />
        <Route path="/films/:id" element={<FilmDetails movies={movies} />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
