import React, { useState } from "react";
import { Link } from "react-router-dom";
import "./Cities.css";

export default function Cities() {
  const [hoveredIndex, setHoveredIndex] = useState(null);

  const handleMouseEnter = (index) => {
    setHoveredIndex(index);
  };

  const handleMouseLeave = () => {
    setHoveredIndex(null);
  };

  
  const cities = [
    { city: "Baku", country: "Azerbaijan",people_count: 500000, area: 23423343,image: "/Coat_of_arms_of_Baku.png", descr: "I like this city"},
    { city: "Berlin", country: "Detsch",people_count: 34324, area: 234432,image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Drezden", country: "Detsch",people_count: 234234, area: 23432,image: "/Coat_of_Arms_of_The_City_of_London.png", descr: "I like this city"},
    { city: "Samaxi", country: "Azerbaijan",people_count: 23423423, area: 23423,image: "/Coat_of_arms_of_Baku.png", descr: "I like this city"},
    { city: "London", country: "Angliya",  people_count: 2342342342, area: 102342340, image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Paris", country: "France",people_count: 24234342, area: 32432,image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Moscow", country: "Russia",  people_count: 2342342, area: 102343240, image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Piter", country: "Russia",  people_count: 20230001, area: 134200, image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Kiev", country: "Ukraina", people_count: 234234, area: 23423, image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Oslo", country: "Norway",  people_count: 23432324, area: 102342340, image: "/Coat_of_arms_of_Berlin.png" , descr: "I like this city"},
    { city: "Antalia", country: "Turkey ",  people_count: 2342342, area: 1053650, image: "/Coat_of_arms_of_Berlin.png" , descr: "I like this city"},
    { city: "Adana", country: "Turkey ",  people_count: 234234, area: 6456, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Astana", country: "Turkey", people_count: 234234, area: 4564564, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Tbilis", country: "Georgia",  people_count: 23423001, area: 65754, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Batumi", country: "Georgia",  people_count: 2342342, area: 466546, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Krasnodar", country: "Russia",people_count: 234234,  area: 456453, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Astraxan", country: "Russia",  people_count: 2342334, area: 546465, image: "/Coat_of_arms_of_Berlin.png" , descr: "I like this city"},
  ];


  return (
    <div className="center-flex">
      <h1 style={{ textAlign: "center", fontSize: 150 }}>Cities</h1>
      <ul className="city-list">
        {cities.map((city, index) => (
          <Link key={index} to={`/cities/${index}`}>
            <div className={`city-card ${hoveredIndex === index ? "hovered" : ""} city-card`}
              onMouseEnter={() => handleMouseEnter(index)}
              onMouseLeave={handleMouseLeave} >
              <img style={{width: 200}} src={city.image} />
              <div style={{height:100, width: '100%', paddingLeft: '10%',flexDirection:"column",textAlign: "center"}} className="city-info">
                <h2 style={{fontSize: 30}}>{city.city}</h2> 
                <h5 style={{fontSize: 20}}>{city.country}</h5> 
                <p style={{fontSize: 15}}>People count: {city.people_count}</p>
                <p style={{fontSize: 15}}>Area: {city.area}</p>
              </div>
            </div>
          </Link>
        ))}
      </ul>
    </div>
  );
}
