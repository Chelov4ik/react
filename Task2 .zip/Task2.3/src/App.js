import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import CitiesDetails from "./CitiesDetails"; 
import Cities from "./Cities";

function App() {
  
  const cities = [
    { city: "Baku", country: "Azerbaijan",people_count: 500000, area: 23423343,image: "/Coat_of_arms_of_Baku.png", descr: "I like this city"},
    { city: "Berlin", country: "Detsch",people_count: 34324, area: 234432,image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Drezden", country: "Detsch",people_count: 234234, area: 23432,image: "/Coat_of_Arms_of_The_City_of_London.png", descr: "I like this city"},
    { city: "Samaxi", country: "Azerbaijan",people_count: 23423423, area: 23423,image: "/Coat_of_arms_of_Baku.png", descr: "I like this city"},
    { city: "London", country: "Angliya",  people_count: 2342342342, area: 102342340, image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Paris", country: "France",people_count: 24234342, area: 32432,image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Moscow", country: "Russia",  people_count: 2342342, area: 102343240, image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Piter", country: "Russia",  people_count: 20230001, area: 134200, image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Kiev", country: "Ukraina", people_count: 234234, area: 23423, image: "/Coat_of_arms_of_Berlin.png", descr: "I like this city"},
    { city: "Oslo", country: "Norway",  people_count: 23432324, area: 102342340, image: "/Coat_of_arms_of_Berlin.png" , descr: "I like this city"},
    { city: "Antalia", country: "Turkey ",  people_count: 2342342, area: 1053650, image: "/Coat_of_arms_of_Berlin.png" , descr: "I like this city"},
    { city: "Adana", country: "Turkey ",  people_count: 234234, area: 6456, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Astana", country: "Turkey", people_count: 234234, area: 4564564, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Tbilis", country: "Georgia",  people_count: 23423001, area: 65754, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Batumi", country: "Georgia",  people_count: 2342342, area: 466546, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Krasnodar", country: "Russia",people_count: 234234,  area: 456453, image: "/Coat_of_Arms_of_The_City_of_London.png" , descr: "I like this city"},
    { city: "Astraxan", country: "Russia",  people_count: 2342334, area: 546465, image: "/Coat_of_arms_of_Berlin.png" , descr: "I like this city"},
  ];


  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Cities cities={cities} />} />
        <Route path="/cities" element={<Cities cities={cities} />} />
        <Route path="/cities/:id" element={<CitiesDetails cities={cities} />} />
      </Routes>
    </BrowserRouter>
  );
}

export default App;
