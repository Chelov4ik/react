import React from 'react';
import { useParams, useNavigate } from 'react-router-dom';

const CitiesDetails = ({ cities }) => {
  const { id } = useParams(); //id из ссылки 
  const city = cities[parseInt(id)]; 

  const navigate = useNavigate();

  const navigateTo = (path) => {
    navigate(path);
  };

  if (!city) {
    return <div>city не найден</div>;
  }

  return (
    <div className="center-flex" style={{display:'flex', flexDirection:'column',alignItems: 'center',textAlign:'center'}}>
      <div className="city-details" style={{paddingBottom:15}}>
        <img src={city.image} style={{width: '100%'}}/>
        <h1 style={{fontSize: 60, paddingTop: 15}}>{city.city}</h1>
        <p style={{fontSize: 45, paddingTop: 15}}>Country: {city.country}</p>
        <p style={{fontSize: 35, paddingTop: 15,color:'gray'}}>People Count: {city.people_count}</p>
        <p style={{fontSize: 35, paddingTop: 15,color:'gray'}}>Area: {city.area}</p>
        <p style={{fontSize: 30, paddingTop: 15,wordBreak: 'break-all', marginLeft: 50,marginRight:50}}>Details: {city.descr}</p>
      </div>
      <button onClick={() => navigateTo("/")} style={{backgroundColor: 'black', color: 'white',width: 300,height: 90, borderRadius: '10px', fontSize: 30}}>Back</button>
    </div>
  );
}

export default CitiesDetails;
