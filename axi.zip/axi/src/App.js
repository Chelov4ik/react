import './App.css';
import Api from './Api';

function App() {
  return (
    <div className="App">
      <Api />
    </div>
  );
}

export default App;
