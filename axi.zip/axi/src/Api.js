import React, { useState } from 'react';
import axios from 'axios';

const Api = () => {
    const [authToken, setAuthToken] = useState('');
    const [error, setError] = useState('');

    const handleLogin = () => {
        axios.post("https://dummyjson.com/auth/login", {
            username: 'emilys',
            password: 'emilyspass'
        }, {
            headers: {
                'Content-Type': 'application/json'
            }
        })
        .then(response => {
            console.log('Log in');
            setAuthToken(response.data.token);
            setError(''); 
        })
        .catch(error => {
            console.error('Log in error:', error);
            setError('Error');
            setAuthToken('');
        });
    };

    const handleLogout = () => {
        console.log('Log out');
        setAuthToken('');
        setError(''); 
    };

    return (
        <div>
            <h1>Log in</h1>
            <button disabled={authToken} onClick={handleLogin}>Log in</button>
            <button disabled={!authToken} onClick={handleLogout}>Log out</button>
            <p>Auth Token: {authToken}</p>
            {error && <p style={{ color: 'red' }}>Error: {error}</p>}
        </div>
    );
};

export default Api;
