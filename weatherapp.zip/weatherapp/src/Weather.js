import React, { useState, useEffect } from 'react';
import axios from 'axios';
import './Weather.css';
import { FontAwesomeIcon } from '@fortawesome/react-fontawesome';
import { faSun, faCloud, faCloudRain, faSnowflake, faMoon } from '@fortawesome/free-solid-svg-icons';

const Weather = () => {
  const [weatherData, setWeatherData] = useState(null);
  const [city, setCity] = useState('Baku');
  const [country, setCountry] = useState('');
  const [cityName, setCityName] = useState('');
  const [sunrise, setSunrise] = useState(null);
  const [sunset, setSunset] = useState(null);
  const [isDayTime, setIsDayTime] = useState(true); 
  const apiKey = '47478f15611dfb962a8bed4a4f33a079';

  const fetchWeather = async () => {
    try {
      let response;
      if (city !== '') {
        if (country !== '') {
          response = await axios.get(
            `https://api.openweathermap.org/data/2.5/weather?q=${city},${country}&appid=${apiKey}&units=metric`
          );
        } else {
          response = await axios.get(
            `https://api.openweathermap.org/data/2.5/weather?q=${city}&appid=${apiKey}&units=metric`
          );
        }
        setWeatherData(response.data);
        setCityName(city);

        if (response.data && response.data.sys) {
          let { sunrise, sunset } = response.data.sys;
          setSunrise(new Date(sunrise * 1000));
          setSunset(new Date(sunset * 1000));
        }
      }
    } catch (error) {
      console.error('Error fetching weather:', error);
      setCityName("No city");
    }
  };

  const getWeatherIcon = (weatherCode) => {
    switch (weatherCode) {
      case '01d':
      case '01n':
        return <FontAwesomeIcon icon={faSun} />;
      case '02d':
      case '02n':
      case '03d':
      case '03n':
      case '04d':
      case '04n':
      case '50d':
      case '50n':
        return <FontAwesomeIcon icon={faCloud} />;
      case '09d':
      case '09n':
      case '10d':
      case '10n':
      case '11d':
      case '11n':
        return <FontAwesomeIcon icon={faCloudRain} />;
      case '13d':
      case '13n':
        return <FontAwesomeIcon icon={faSnowflake} />;
      default:
        return <FontAwesomeIcon icon={faMoon} />;
    }
  };

  useEffect(() => {
    fetchWeather();
    const currentTime = new Date().getHours();
    setIsDayTime(currentTime >=5 && currentTime <=22); 
  }, []); 

  const dayGradient = 'linear-gradient(to right, #5cb7bd, #84cdd1)';
  const nightGradient = 'linear-gradient(to right, #5a7fd6, #819ee3)';
  const overlayBackDay = 'rgba(128, 128, 128, 0.322)';
  const overlayBackNight = 'rgba(255, 255, 255, 0.222)';

  return (
    <div className="container" style={{ 
      backgroundImage: isDayTime ? dayGradient : nightGradient}}>
      <div className='overlay' style={{backgroundColor: isDayTime ? overlayBackDay : overlayBackNight}}>
        <h1 style={{ fontSize: 67 }}>Weather</h1>
        <div className="input-container" style={{paddingTop: 30}} >
          <input
            type="text"
            value={city}
            onChange={(e) => setCity(e.target.value)}
            placeholder="City"
            style={{ fontSize: 20, padding: 10, borderRadius: 15, width: '300px', transition: 'all 0.3s ease' }}
          />
          <input
            type="text"
            value={country}
            onChange={(e) => setCountry(e.target.value)}
            placeholder="Country CODE (optional)"
            maxLength={2}
            style={{ fontSize: 20, marginTop: 10, padding: 10, borderRadius: 15, width: '300px', transition: 'all 0.3s ease' }}
          />
          <button
            onClick={fetchWeather}
            style={{ marginTop: 30, padding: '15px', fontSize: 20, border: 'none', borderRadius: 15, backgroundColor: '#007BFF', color: 'white', cursor: 'pointer', transition: 'background-color 0.3s ease' }}
          >
            Get Weather
          </button>
        </div>
      </div>
      <div className='overlay2' style={{backgroundColor: isDayTime ? overlayBackDay : overlayBackNight}}>
        {weatherData && (
          <div style={{fontSize: 30, display: 'flex', flexDirection: 'column', alignItems: 'center', paddingTop: 100}}>
            <div className="container2">
              <div className="weather-icon" style={{marginRight: 10}}>
                {getWeatherIcon(weatherData.weather[0].icon)}
              </div>
              <h2 className='cityName' style={{fontSize: 70, color: 'black', margin: 0}}>
                {cityName}
              </h2>
            </div>
            <p>{weatherData.weather[0].description}</p>
            <h1 style={{paddingTop: 10}}>{weatherData.main.temp}°C</h1>
            <div className='container3'>
              <img src='/SunRise.png' alt="Sunrise" style={{width: 50, marginRight:10}}/>
              <img src='/Rise.png' alt="Sunset" style={{width: 50, marginLeft:10}}/>
            </div>
            <div className='container3'>
              <h2 style={{fontSize:15}}>
                {sunrise ? `${sunrise.getHours().toString().padStart(2, '0')}:${sunrise.getMinutes().toString().padStart(2, '0')}:${sunrise.getSeconds().toString().padStart(2, '0')}` : ''}
              </h2>
              <div> | </div>
              <h2 style={{fontSize:15}}>
                {sunset ? `${sunset.getHours().toString().padStart(2, '0')}:${sunset.getMinutes().toString().padStart(2, '0')}:${sunset.getSeconds().toString().padStart(2, '0')}` : ''}
              </h2>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Weather;
