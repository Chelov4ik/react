import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import './Navbar.css'; // Импортируем файл стилей

const Navbar = () => {
  const location = useLocation();
  const shouldHideAuthLinks = location.pathname === '/todolist';

  return (
    <nav className="navbar">
      <div className="navbar-container">
      {shouldHideAuthLinks && (
            <>
            <div className="li" style={{color: 'white', display: 'flex'}}>
                <Link to="/login">Exit</Link>
            </div>
            </>
          )}
        
        <ul className="nav-links">
          {!shouldHideAuthLinks && (
            <>
              <li>
                <Link to="/login">Login</Link>
              </li>
              <li>
                <Link to="/register">Register</Link>
              </li>
            </>
          )}
        </ul>
      </div>
    </nav>
  );
};

export default Navbar;
