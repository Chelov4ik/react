import "./App.css";
import { BrowserRouter, Routes, Route } from "react-router-dom";
import Navbar from "./Navbar";
import Login from "./Login";
import Register from "./Register";
import ToDoList from "./ToDoList";

function App() {
  return (
    <div className="App">
      <BrowserRouter>
        <Navbar /> {/* Добавляем Navbar */}
        <Routes>
          <Route path="/todolist" element={<ToDoList />} />
          <Route path="/login" element={<Login />} />
          <Route path="/register" element={<Register />} />
        </Routes>
      </BrowserRouter>
    </div>
  );
}

export default App;
