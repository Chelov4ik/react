import React, { useState } from 'react';
import './App.css';
import { useNavigate } from "react-router-dom";

export default function ToDoList() {
    const navigate = useNavigate();

    const navigateTo = (path) => {
        navigate(path);
    };

    const [task, setTask] = useState('');
    const [tasks, setTasks] = useState([]);
  
    const handleAddTask = () => {
      if (task.trim()) {
        setTasks([...tasks, task]);
        setTask('');
      }
    };
  
    return (
      <div className="App">
        <div className='container' style={{ display: 'flex'}}>
          <div className='centered-div' style={{ height: 300, width: 200, backgroundColor: 'greenyellow', marginRight: 30, borderRadius: 30}}>
            Task Name:
            <textarea
              value={task}
              onChange={(e) => setTask(e.target.value)}
              style={{ width: '100%', height: '80%', maxHeight: '80%' }}
            ></textarea>
            <button onClick={handleAddTask} style={{backgroundColor: 'grey', width: 100,fontSize: 25}}>Save</button>
          </div>
          <div className='centered-div' style={{ height: 300, width: 200, backgroundColor: 'red', marginLeft: 30, position: 'relative', borderRadius: 30 }}>
            <div id='TargetDiv' style={{ height: '85%', overflowY: 'auto' }}>
              {tasks.map((t, index) => (
                <div
                  style={{
                    margin: '10px 0',
                    padding: '10px',
                    backgroundColor: 'lightgray',
                    cursor: 'pointer'
                  }}
                >
                  {t}
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    );
  }
  